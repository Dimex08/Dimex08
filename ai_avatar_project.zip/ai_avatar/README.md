# AI Avatar with Flask, GPT-4, Whisper, ElevenLabs, and D-ID

This project creates a lifelike digital avatar that listens to your voice, generates a response using GPT-4, converts it to speech, and animates a face using D-ID's API.
