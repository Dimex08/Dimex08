import React, { useState } from 'react';

function App() {
  const [response, setResponse] = useState("");
  const [videoUrl, setVideoUrl] = useState("");

  const recordAndSend = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mediaRecorder = new MediaRecorder(stream);
    const chunks = [];

    mediaRecorder.ondataavailable = e => chunks.push(e.data);
    mediaRecorder.onstop = async () => {
      const blob = new Blob(chunks, { type: 'audio/webm' });
      const formData = new FormData();
      formData.append("audio", blob, "voice.webm");

      const res = await fetch("http://localhost:5000/talk", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      setResponse(data.reply);

      const didRes = await fetch("https://api.d-id.com/talks", {
        method: "POST",
        headers: {
          "Authorization": "Bearer YOUR_DID_API_KEY",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          script: { type: "audio", audio_url: data.audio_url, provider: "external" },
          source_url: "https://example.com/avatar.jpg"
        })
      });
      const didData = await didRes.json();
      setVideoUrl(didData.result_url);
    };

    mediaRecorder.start();
    setTimeout(() => mediaRecorder.stop(), 5000);
  };

  return (
    <div>
      <h1>Talk to AI Avatar</h1>
      <button onClick={recordAndSend}>🎙️ Talk</button>
      <p>Response: {response}</p>
      {videoUrl && <video src={videoUrl} autoPlay controls />}
    </div>
  );
}

export default App;
