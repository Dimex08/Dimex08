from flask import Flask, request, jsonify
from utils.whisper import transcribe_audio
from utils.gpt import get_gpt_response
from utils.tts import text_to_speech
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route("/talk", methods=["POST"])
def talk():
    audio = request.files["audio"]
    transcript = transcribe_audio(audio)
    reply = get_gpt_response(transcript)
    audio_url = text_to_speech(reply)
    return jsonify({"reply": reply, "audio_url": audio_url})
