import requests
import os
import uuid

def text_to_speech(text):
    api_key = os.getenv("ELEVENLABS_API_KEY")
    voice_id = os.getenv("ELEVENLABS_VOICE_ID")
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"

    response = requests.post(
        url,
        headers={"xi-api-key": api_key},
        json={"text": text, "voice_settings": {"stability": 0.75, "similarity_boost": 0.75}},
    )

    filename = f"backend/static/audio_{uuid.uuid4()}.mp3"
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, "wb") as f:
        f.write(response.content)

    return f"http://localhost:5000/{filename}"
